
class Company {
  String urlLogo;
  String name;

  Company({this.urlLogo, this.name});
}