
# Job Finder App Preview
### [Watch Video tutorial on Youtube](https://youtu.be/DAroZ2-OAaY)
<img alt="Preview" width="550px" src="https://github.com/CrissAlvarezH/JobFinderApp/blob/master/preview/job_find_app.jpg" />

### [Design by Julia Nasser](https://dribbble.com/julianasser)


