package com.example.curso_job_finder_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
